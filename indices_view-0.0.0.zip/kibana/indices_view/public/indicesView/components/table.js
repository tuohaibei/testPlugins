/* eslint-disable quotes */
/* eslint-disable import/no-unresolved */
/*
 * Licensed to Elasticsearch B.V. under one or more contributor
 * license agreements. See the NOTICE file distributed with
 * this work for additional information regarding copyright
 * ownership. Elasticsearch B.V. licenses this file to you under
 * the Apache License, Version 2.0 (the "License"); you may
 * not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */
import React, { Component, Fragment } from 'react';
import $ from 'jquery';
import { MBG } from 'mbg';
import {
  EuiInMemoryTable,
  EuiSpacer,
  EuiSwitch,
  EuiFlexItem,
  EuiFlexGroup,
  EuiFieldText,
  EuiNotificationBadge
} from '@elastic/eui';
import './mds.css';
import '../less/main.less';

class IndicesObj {
  constructor(description, contentType, location, name, path, tag) {
    this.description = description;
    this.key = description;
    this.content_type = contentType;
    this.location = location;
    this.name = name;
    this.path = path;
    this.tag = tag;
  }
}

const renderNum = (numValue) => {
  {
    let num = (numValue || 0).toString();
    let result = '';
    while (num.length > 3) {
      result = ',' + num.slice(-3) + result;
      num = num.slice(0, num.length - 3);
    }
    if (num) {
      result = num + result;
    }
    return result;
  }
};

const formatBytes = (size) => {
  const kb = 1024;
  const mb = 1024 * 1024;
  const gb = 1024 * 1024 * 1024;
  const tb = 1024 * 1024 * 1024 * 1024;
  if (size > tb) {
    size = (size / tb).toFixed(2) + ' tb';
  } else if (size > gb) {
    size = (size / gb).toFixed(2) + ' gb';
  } else if (size > mb) {
    size = (size / mb).toFixed(2) + ' mb';
  } else {
    size = (size / kb).toFixed(2) + ' kb';
  }
  return size;
};

let debounceTimeoutId;
let requestTimeoutId;
export default class Table extends Component {
  constructor(props) {
    super(props);
    this.queryIndicesStats = this
      .queryIndicesStats
      .bind(this);
    this.onPatternChange = this
      .onPatternChange
      .bind(this);
    this.handelChange = this
      .handelChange
      .bind(this);
    // this.resize = this
    //   .resize
    //   .bind(this);
    this.state = {
      merge: true,
      filters: false,
      store: [],
      isLoading: true,
      queryParam: null,
      indexSize: 0,
      doc: 0,
      storeSize: 0,
      shards: 0,
      mergePattern: this.props.mergePattern,
      basegrid: null
    };
  }
  /**
   * 构建页面展示所需要格式数据
   * @param {*} orignData
   */
  reBuildOriginData(orignData) {
    const newOrignData = new Array();
    console.log(orignData)
    for (const key in orignData) {
      if (orignData.hasOwnProperty(key)) {
        const element = orignData[key];
        console.log(element);
        const obj = new IndicesObj(key, element.content_type, element.description,
          element.location, element.name, element.path,
          element.tag);
        console.log(obj);
        newOrignData.push(obj);
      }
    }
    return newOrignData;
  }

  /**
   * 合并index，并计算大小
   * @param {*} tempData
   */
  mergetdescription(tempData, pattern) {

    const resultDataArray = new Array();
    const map = new Map();
    const regx = new RegExp(pattern);
    for (const key in tempData) {
      if (tempData.hasOwnProperty(key)) {
        const result = regx.exec(key);
        let prefix = '';
        if (result != null && result.index > 0) {
          prefix = key.substring(0, result.index);
        } else {
          prefix = key;
        }
        if (map.has(prefix)) {
          const temp = map.get(prefix);
          temp.push(tempData[key]);
          map.set(prefix, temp);
        } else {
          const temp = new Array();
          temp.push(tempData[key]);
          map.set(prefix, temp);
        }
      }
    }
    map
      .forEach(function (value, key) {
        let size = 0;
        let location = 0;
        let name = 0;
        let path = 0;

        let search = 0;
        let get = 0;
        let query = 0;
        console.log(value);
        for (const data of value) {
          console.log(data);
          const indexSize = data.total.store.size_in_bytes;
          size = size + indexSize;
          location = location + data.total.docs.count;
          name = name + data.primaries.store.size_in_bytes;
          path = path + data.primaries.docs.count;
          search = search + data.total.search.query_total;
          get = get + data.total.get.total;
          query = query + data.total.query_cache.total_count;
        }
        const obj = new IndicesObj(key + '*(' + value.length + ')', size, location, name, path, search, get, query);
        resultDataArray.push(obj);
      });
    console.log(resultDataArray)
    return resultDataArray;
  }

  queryIndicesStats() {
    this.setState({ isLoading: true });
    //axios.defaults.headers.common = {};
    //axios.defaults.headers.common.accept = 'application/json'; 
    // 使用 axios 获取数据
    const container = document.getElementById('metaData');
    container.attributes.id = 'dataDiv';
    container.style.width = '100%';
    container.style.height = '800px';
    container.style.overflowX = 'scroll';
    const mbg = new MBG(container);
    console.log('get data');
    $.ajax({
      method: 'GET',
      url: 'http://127.0.0.1:8000/api/elasticsearch/index/search/',
      dataType: 'json',
      kbnXsrfToken: false,
      async: false,
      data: '',
      success: function (data) {
        const indices = data;
        console.log(indices);
        this.setState({
          store: indices,
          isLoading: false,
          basegrid: mbg
        });
        // const container = document.getElementById('metaData');
        // container.attributes.id = 'dataDiv';
        // container.style.width = '100%';
        // container.style.height = '800px';
        // container.style.overflowX = 'scroll';
        // const mbg = new MBG(container);
        mbg.setOption({
          sortField: 'name'
        });
        mbg.setData({
          columns: [{
            id: 'name',
            name: 'Name',
            width: 300
          }, {
            id: 'content_type',
            name: 'content_type',
            width: 100
          },
          {
            id: 'path',
            name: 'path',
            width: 300
          },
          {
            id: 'specs',
            name: 'specs',
            width: 100
          },
          {
            id: 'description',
            name: 'description',
            width: 200
          },
          {
            id: 'tag',
            name: 'tag',
            width: 300
          }],
          rows: data
        });
        mbg.render();
        const columnData = mbg.getColumnItem(2);
        mbg.setColumnWidth(columnData, 400);
        mbg.resize();
      }.bind(this),
      beforeSend: function (xhr) {       
        //xhr.setRequestHeader('Access-Control-Request-Headers', 'Authorization');
        //xhr.setRequestHeader('Access-Control-Request-Method', 'GET');
      },
      error: function (xhr, status, err) {
        // alert(xhr.responseText);
        // alert(xhr.status);
        // alert(xhr.readyState);
        // alert(xhr.statusText);
        // alert(status);
        // alert(err);
        console.log(status.toString() + err.toString());
      }.bind(this)
    });
  }

  componentDidMount() {
    this.queryIndicesStats();
  }

  componentDidUpdate()
  {
    window.addEventListener("resize", function () {
      // eslint-disable-next-line no-undef
      //this.resize();
    });
  }

  // resize() {
  //   const mbg = this.store.basegrid;
  //   const container = document.getElementById("metaData");
  //   const columnIcon = mbg.getColumnItem(1);
  //   const scrollbarWidth = mbg.getScrollBarWidth();
  //   const cw = container.offsetWidth;
  //   const dw = cw - columnIcon.width - scrollbarWidth;
  //   const columnData = mbg.getColumnItem(0);
  //   mbg.setColumnWidth(columnData, dw);
  //   mbg.resize();
  // }

  mergeFilter(_this) {
    let store = [];
    if (!_this.state.merge) {
      store = _this.mergetdescription(this.state.indices, this.state.mergePattern);
    } else {
      store = _this.reBuildOriginData(this.state.indices);
    }
    //处理queryParam需要过滤的数据
    if (this.state.queryParam != null) {
      const indicesObjs = store.filter(indicesObj => {
        const normalizedName = `${indicesObj
          .description}`
          .toLowerCase();
        const normalizedQuery = this
          .state
          .queryParam
          .toLowerCase();
        return normalizedName.indexOf(normalizedQuery) !== -1;
      });
      store = indicesObjs;
    }


    _this.setState({
      store: store,
      merge: !_this.state.merge
    });
  }
  onPatternChange() {
    let store = [];
    if (this.state.merge) {
      store = this.mergetdescription(this.state.indices, this.state.mergePattern);
    } else {
      store = this.reBuildOriginData(this.state.indices);
    }
    this.setState({ store: store });
  }

  handelChange(e) {
    this.setState({ mergePattern: e.target.value });
  }
  renderToolsRight() {
    return [(<EuiFieldText
      placeholder="Merget Pattern"
      defaultValue={this.state.mergePattern}
      onBlur={this.onPatternChange}
      onChange={this.handelChange}
    />),
      (<EuiSwitch
        label="Merge"
        key="MergeEuiSwitch"
        checked={this.state.merge}
        onChange={() => this.mergeFilter(this)}
      />)];
  }

  onQueryChange = ({ query }) => {
    clearTimeout(debounceTimeoutId);
    clearTimeout(requestTimeoutId);

    debounceTimeoutId = setTimeout(() => {
      this.setState({ isLoading: true });

      requestTimeoutId = setTimeout(() => {
        let store = [];
        if (this.state.merge) {
          store = this.mergetdescription(this.state.indices, this.state.mergePattern);
        } else {
          store = this.reBuildOriginData(this.state.indices);
        }
        const indicesObjs = store.filter(indicesObj => {
          const normalizedName = `${indicesObj
            .description}`
            .toLowerCase();
          const normalizedQuery = query
            .text
            .toLowerCase();
          return normalizedName.indexOf(normalizedQuery) !== -1;
        });

        this.setState({ isLoading: false, store: indicesObjs, queryParam: query.text });
      }, 1000);
    }, 300);
  };

  render() {
    const columns = [
      {
        field: 'description',
        name: 'description',
        sortable: true,
        render: () => <span className="tablerow" />,
        truncateText: false
      }, {
        field: 'tag',
        name: 'tag',
        sortable: true,
        width: '30%',
        truncateText: false
      }, {
        field: 'location',
        name: 'location',
        sortable: true
      }, {
        field: 'content_type',
        name: 'content_type',
        sortable: true
      }, {
        field: 'path',
        name: 'path',
        sortable: true
      }, {
        field: 'name',
        name: 'name',
        sortable: true
      }
    ];

    const sorting = {
      sort: {
        field: 'content_type',
        direction: 'desc'
      }
    };
    const search = {
      onChange: this.onQueryChange,
      box: {
        incremental: true
      },
      toolsRight: this.renderToolsRight()
    };
    const page = (
      <Fragment>
        <EuiSpacer size="l" />
        <EuiInMemoryTable
          className="table"
          items={this.state.store}
          loading={this.state.isLoading}
          columns={columns}
          //search={search}
          pagination={true}
        //sorting={sorting}
        />
      </Fragment>
    );
    return (
      <div id="metaData" />
    );
  }
}
